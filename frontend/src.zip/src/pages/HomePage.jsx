import React from 'react';

const HomePage = () => {
  return (
    <div>
      <h1>This is the Home Page</h1>
      <p>This will be the landing page.</p>
    </div>
  );
};

export default HomePage;

import React from 'react';
import { Routes, Route } from 'react-router-dom';
import CoverPage from '../pages/inspection_worksheets/CoverPage';

const InspectionForm = () => {
  return (
    <Routes>
      <Route path="/inspection-form/:propertyId/cover-page" element={<CoverPage />} />
    </Routes>
  );
};

export default InspectionForm;
